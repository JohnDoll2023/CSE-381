/* 
 * A very lightweight (light as air) implementation of a simple CSV-based 
 * database system that uses SQL-like syntax for querying and updating the
 * CSV files.
 * 
 */

#include <string>
#include <fstream>
#include <tuple>
#include <algorithm>
#include "SQLAir.h"
#include "HTTPFile.h"

/**
 * A fixed HTTP response header that is used by the runServer method below.
 * Note that this a constant (and not a global variable)
 */
const std::string HTTPRespHeader = "HTTP/1.1 200 OK\r\n"
    "Server: localhost\r\n"
    "Connection: Close\r\n"
    "Content-Type: text/plain\r\n"
    "Content-Length: ";

// API method to perform operations associated with a "select" statement
// to print columns that match an optional condition.
void SQLAir::selectQuery(CSV& csv, bool mustWait, StrVec colNames, 
        const int whereColIdx, const std::string& cond, 
        const std::string& value, std::ostream& os) {
    // Convert any "*" to suitable column names. See CSV::getColumnNames()
    
    // First print the column names.
    os << colNames << std::endl;
    // Print each row that matches an optional condition.
    for (const auto& row : csv) {
        // Determine if this row matches "where" clause condition, if any
        // see SQLAirBase::matches() helper method.
        std::string delim = "";
        for (const auto& colName : colNames) {
            os << delim << row.at(csv.getColumnIndex(colName));
            delim = "\t";
        }
        os << std::endl;
    }
}

void
SQLAir::updateQuery(CSV& csv,  bool mustWait, StrVec colNames, StrVec values, 
        const int whereColIdx, const std::string& cond, 
        const std::string& value, std::ostream& os)  {
    // Update each row that matches an optional condition.
    throw Exp("update is not yet implemented.");
}


void 
SQLAir::insertQuery(CSV& csv, bool mustWait, StrVec colNames, 
        StrVec values, std::ostream& os) {
    throw Exp("insert is not yet implemented.");
}

void 
SQLAir::deleteQuery(CSV& csv, bool mustWait, const int whereColIdx, 
        const std::string& cond, const std::string& value, std::ostream& os) {
    throw Exp("delete is not yet implemented.");
}

// The method to have this class run as a web-server. 
void 
SQLAir::runServer(boost::asio::ip::tcp::acceptor& server, const int maxThr) {
    throw Exp("runServer method is not yet implemented.");
}

// Convenience helper method to return the CSV object for a given
// file or URL.
CSV& SQLAir::loadAndGet(std::string fileOrURL) {
    // If the parameter is empty string, we use our most recent as default.
    if (fileOrURL == "") {
        std::lock_guard<std::mutex> guard(recentCSVMutex);
        fileOrURL = recentCSV;  // use most recent CSV as the default.
    }
    // If the requested data is already in-memory then just return it
    if (inMemoryCSV.find(fileOrURL) == inMemoryCSV.end()) {
        // The data was not in memory. So we need to load it
        CSV csv;   // Load data into this csv
        if (fileOrURL.find("http://") == 0) {
            // This is an URL. We have to get the stream from a web-server
            // Implement this feature.
            std::string host, port, path;
            std::tie(host, port, path) = Helper::breakDownURL(fileOrURL);
            throw Exp("Loading CSV from ULR not implemented.");
        } else {
            // We assume it is a local file on the server. Load that file.
            std::ifstream data(fileOrURL);
            csv.load(data);  // This method may throw exceptions.
        }
        // Move (instead of copy) the CSV data into our in-memory CSVs
        inMemoryCSV[fileOrURL].move(csv);
    }
    // When control drops here, we must have a CSV to return
    std::lock_guard<std::mutex> guard(recentCSVMutex);
    recentCSV = fileOrURL;   // Update most recently used CSV as default.
    return inMemoryCSV.at(fileOrURL);
}

// Save the currently loaded CSV file to a local file.
void 
SQLAir::saveQuery(std::ostream& os) {
    if (recentCSV.empty() || recentCSV.find("http://") == 0) {
        throw Exp("Saving CSV to an URL using POST is not implemented");
    }
    // Create a local file and have the CSV write itself.
    std::ofstream csvData(recentCSV);
    inMemoryCSV.at(recentCSV).save(csvData);
    os << recentCSV << " saved.\n";
}
